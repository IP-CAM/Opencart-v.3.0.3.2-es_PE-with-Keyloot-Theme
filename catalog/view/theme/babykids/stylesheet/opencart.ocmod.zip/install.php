<?php
$tables=$this->db->query("show tables like '" . DB_PREFIX . "product_bundle'");
if($tables->num_rows)
$this->db->query("DROP TABLE " . DB_PREFIX . "product_bundle");

$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "product_bundle` ( `product_id` INT(11) NOT NULL , `bundled_id` INT(11) NOT NULL, `qty` INT(4) NOT NULL DEFAULT '1' )");

$ifcolumn=$this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "cart` LIKE 'bundled'");
if(!$ifcolumn->num_rows){
$this->db->query("ALTER TABLE `" . DB_PREFIX . "cart` ADD `bundled` TINYINT(1) NOT NULL DEFAULT '0'");
}


